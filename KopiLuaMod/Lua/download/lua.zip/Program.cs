﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tuxen.Utilities.Lua;

namespace ShowLuaSampleClassInUse
{
    /// <summary>
    /// Sample console program to illustrate the use of the basic lua script engine
    /// </summary>
    class Program
    {
        private static string _luaScript = "print('Fancy hero in combat ? ' .. tostring(NPCPlayer.incombat('fancyhero')))";
        private static string _luaScriptWithError = "print('Fancy hero in combat ? ' .. tostring(NPCPlayer.incombat('fancyhero', 1)))";

        static void Main(string[] args)
        {
            ScriptEngine engine = new ScriptEngine();
            NPCPlayer fancyHeroFromThePlaneOfBeyondIllusions = new NPCPlayer(engine);
            fancyHeroFromThePlaneOfBeyondIllusions.SetupNPCPLayerInLua();

            Console.WriteLine("Executing a lua script without any errors:");
            Program.DiplayAnyErrors(engine.RunLuaScript(_luaScript));
            Console.WriteLine();
            Console.WriteLine("Executing a lua script with an error:");
            Program.DiplayAnyErrors(engine.RunLuaScript(_luaScriptWithError));

            Console.WriteLine("");
            Console.WriteLine("Press a key to exit");
            Console.ReadLine();
            engine.StopEngineAndCleanup();
        }

        private static void DiplayAnyErrors(bool noError)
        {
            if (noError)
                return;
            //a lua_error was raised when running the script
            if (ScriptEngine.Errors.Any())
            {
                ScriptEngine.Errors.ForEach(x => Console.WriteLine(x));
                ScriptEngine.Errors.Clear();
            }
        }
    }
}
