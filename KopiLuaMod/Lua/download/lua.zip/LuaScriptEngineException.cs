using System;

namespace Tuxen.Utilities.Lua
{
    public class LuaScriptEngineException : Exception
    {
        public LuaScriptEngineException(string msg)
            : base(msg)
        {
        }
    }
}
