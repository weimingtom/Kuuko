﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tuxen.Utilities.Lua
{
    /// <summary>
    /// Sample class using the managed lua wrapper directly
    /// </summary>
    public class NPCPlayer
    {
        ScriptEngine _engine = null;

        public NPCPlayer(ScriptEngine engine)
        {
            _engine = engine;
        }

        /// <summary>
        /// This method is not exposed to lua, but is instead called by Lua_InCombat.
        /// This pattern ensures separation of lua communication handling inside Lua_InCombat and game/business logic.
        /// </summary>
        /// <param name="characterName"></param>
        /// <returns></returns>
        bool InCombat(string characterName)
        {
            //not implemented, always in combat
            return true;
        }

        /// <summary>
        /// This method matches the signature that lua requires for method registration.
        /// Register this method with lua to be able to use it in a lua script file
        /// </summary>
        /// <param name="m_lua_State">the lua state pointer</param>
        /// <returns>lua signatured methods always return an int, 
        /// to return any other type use the lua stack and pass the value there
        /// </returns>
        int Lua_InCombat(IntPtr m_lua_State)
        {
            //get the characterName from Lua
            string cName = string.Empty;
            //if theres a sring argument on top of the stack, LUA_TSTRING = 4 see lua.h
            if (Lua.lua_type(m_lua_State, -1) == 4)
            {
                cName = Lua.lua_tostring(m_lua_State, -1);
                //pop value from stack
                Lua.lua_pop(m_lua_State, 1);
                //the stack is now 'balanced', we got 1 argument, we popped 1 argument

                //now return 1 argument based on the result from InCombat(string)
                //push the return value on the stack and return 1 to signal 1 return value
                Lua.lua_pushboolean(m_lua_State, InCombat(cName));
                return 1;
            }
            else
            {
                //error, invalid argument or no argument on the Lua stack
                //check Lua script for errors and optionally ask Lua for an error message
                //clear the stack
                Lua.lua_settop(m_lua_State, 0);
            }

            //push an error message onto the stack
            //call lua_error to signal a lua script error to lua. 
            //lua_error will consume the value at the top of the stack
            //the error will be signalled in the return value of the script engines RunLuaScript
            //the script engine will then log the error, and the user of script engine will display any errors
            Lua.lua_pushstring(m_lua_State, "invalid argument to function: incombat(string name)");
            return Lua.lua_error(m_lua_State);
        }

        /// <summary>
        /// This method sets up the NPCPlayer class for usage with lua scripts.
        /// First it registers relevant class methods with lua
        /// Then it creates a lua table named NPCPlayer.
        /// On the table a field named incombat is set up, and that field is pointing to the registered lua
        /// method, known by the lua identifier of the name identical to field: incombat (does not have to match ofcourse)
        /// </summary>
        /// <param name="engine">the script engine to use for communicating with lua</param>
        public void SetupNPCPLayerInLua()
        {
            if (_engine == null)
                return;

            RegisterMethodsWithLua();
            CreateLuaTables();
            AssociateTableFieldsWithRegisteredFunctions();
        }

        private void RegisterMethodsWithLua()
        {
            _engine.RegisterLuaFunction(new Lua.LuaFunction(Lua_InCombat), "incombat");
        }

        private void CreateLuaTables()
        {
            _engine.CreateLuaTable("NPCPlayer");
        }

        private void AssociateTableFieldsWithRegisteredFunctions()
        {
            _engine.SetTableFieldToLuaIdentifier("NPCPlayer", "incombat", "incombat");
        }
    }
}
